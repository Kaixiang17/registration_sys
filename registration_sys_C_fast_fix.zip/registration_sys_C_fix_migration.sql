-- registration_sys C 方案相容 migration
-- 可手動在 DBeaver 執行；若已部署新版 server.py，/api/bootstrap_db 也會自動補欄位。
ALTER TABLE event_configs ADD COLUMN success_card_config LONGTEXT;
ALTER TABLE event_configs ADD COLUMN success_info_cards_config LONGTEXT;
ALTER TABLE event_configs ADD COLUMN dashboard_agenda_config LONGTEXT;
ALTER TABLE event_configs ADD COLUMN theme_background_color VARCHAR(20) DEFAULT '#061A18';
ALTER TABLE event_configs ADD COLUMN theme_primary_color VARCHAR(20) DEFAULT '#14B8A6';
ALTER TABLE event_configs ADD COLUMN theme_accent_color VARCHAR(20) DEFAULT '#5EEAD4';
ALTER TABLE event_configs ADD COLUMN theme_text_color VARCHAR(20) DEFAULT '#ECFEFF';
ALTER TABLE event_configs ADD COLUMN map_title VARCHAR(255);
ALTER TABLE event_configs ADD COLUMN map_subtitle VARCHAR(255);
ALTER TABLE event_configs ADD COLUMN map_description LONGTEXT;
ALTER TABLE event_configs ADD COLUMN map_enabled BOOLEAN DEFAULT TRUE;
ALTER TABLE event_registrations ADD COLUMN portrait_consent TINYINT(1) DEFAULT NULL;
ALTER TABLE event_registrations ADD COLUMN portrait_consent_status VARCHAR(20);
ALTER TABLE event_registrations ADD COLUMN portrait_consent_time DATETIME NULL;
ALTER TABLE event_registrations ADD COLUMN meal_choice VARCHAR(50);
ALTER TABLE event_registrations ADD COLUMN original_meal_choice VARCHAR(50);
